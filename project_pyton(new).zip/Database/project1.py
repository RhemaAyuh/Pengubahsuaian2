from os import stat
from tkinter import *
from tkinter.font import BOLD
from tkinter import messagebox
from project1db import Database
  
project1db=Database('Employee1.db')
workerdb=Database('workerdb.db')

LABEL_FONT = "Adobe Gothic Std"

def populate_list2():
    Generatecar.delete(0, END)
    for row in project1db.fetch():
        Generatecar.insert(END, row)

def add_car():
    if labelpekerjaentry1.get() == '' or labelpekerjaentry2.get() == '' or labelpekerjaentry3.get() == '':
        messagebox.showerror('Required Fields', 'Please include all fields')
        return
    project1db.insert(labelpekerjaentry1.get(),labelpekerjaentry2.get(),labelpekerjaentry3.get())
    Generatecar.delete(0, END)
    Generatecar.insert(END, (labelpekerjaentry1.get(),labelpekerjaentry2.get(),labelpekerjaentry3.get()))
    clear_text()
    populate_list2()

def remove_car():
    project1db.remove(selected_item[0])
    populate_list2()


def clear_car():
    labelpekerja1.delete(0, END)
    labelpekerja2.delete(0, END)
    labelpekerjaentry3.delete(0, END)


def populate_list1():
    parts_list1.delete(0, END)
    for row in project1db.fetch():
        parts_list1.insert(END, row)

def add_item():
    if label1entry.get() == '' or label3entry.get() == '' or Clockinentry.get() == '' or Clockoutentry.get() == '' or dayentry.get() == '' or label2entry.get() == '':
        messagebox.showerror('Required Fields', 'Please include all fields')
        return
    project1db.insert(label1entry.get(),label3entry.get(),Clockinentry.get(),Clockoutentry.get(), dayentry.get(), label2entry.get())
    parts_list1.delete(0, END)
    parts_list1.insert(END, (label1entry.get(),label3entry.get(),Clockinentry.get(),Clockoutentry.get(), dayentry.get(), label2entry.get()))
    clear_text()
    populate_list1()

def remove_item():
    project1db.remove(selected_item[0])
    populate_list1()


def clear_text():
    label1entry.delete(0, END)
    label3entry.delete(0, END)
    Clockinentry.delete(0, END)
    Clockoutentry.delete(0, END)
    dayentry.delete(0, END)
    label2entry.delete(0,END)




def morning():
    label2entry.config(state=NORMAL)
    label2entry.delete(0,"end")
    label2entry.insert(0,"Morning")
    label2entry.config(state=DISABLED)
def afternoon():
    label2entry.config(state=NORMAL)
    label2entry.delete(0,"end")
    label2entry.insert(0,"Afternoon")
    label2entry.config(state=DISABLED)
    

def monday():
    dayentry.config(state=NORMAL)
    dayentry.delete(0,"end")
    dayentry.insert(0,"Monday")
    dayentry.config(state=DISABLED)
def tuesday():
    dayentry.config(state=NORMAL)
    dayentry.delete(0,"end")
    dayentry.insert(0,"Tuesday")
    dayentry.config(state=DISABLED)
def wednesday():
    dayentry.config(state=NORMAL)
    dayentry.delete(0,"end")
    dayentry.insert(0,"Wednesday")
    dayentry.config(state=DISABLED)
def thursday():
    dayentry.config(state=NORMAL)
    dayentry.delete(0,"end")
    dayentry.insert(0,"Thursday")
    dayentry.config(state=DISABLED)
def friday():
    dayentry.config(state=NORMAL)
    dayentry.delete(0,"end")
    dayentry.insert(0,"Friday")
    dayentry.config(state=DISABLED)
def saturday():
    dayentry.config(state=NORMAL)
    dayentry.delete(0,"end")
    dayentry.insert(0,"Saturday")
    dayentry.config(state=DISABLED)
def sunday():
    dayentry.config(state=NORMAL)
    dayentry.delete(0,"end")
    dayentry.insert(0,"Sunday")
    dayentry.config(state=DISABLED)

def select_item1(event):
    try:
        global selected_item
        index = parts_list1.curselection()[0]
        selected_item = parts_list1.get(index)

        label1entry.delete(0, END)
        label1entry.insert(END, selected_item[0])
        label2entry.delete(0, END)
        label2entry.insert(END, selected_item[1])
        Clockinentry.delete(0, END)
        Clockinentry.insert(END, selected_item[2])
        Clockoutentry.delete(0, END)
        Clockoutentry.insert(END, selected_item[3])
        dayentry.delete(0, END)
        dayentry.insert(END, selected_item[4])
        label3entry.delete(0,END)
        label3entry.insert(END, selected_item[5])
    except IndexError:
     pass


window=Tk()
window.geometry("1200x700")
window.minsize(width=1200,height=800)


Labeljak = Label(text= "WELCOME TO AUTOMOBLIE WORKSHOP IN RWANDA" , font=('bold', 22))
Labeljak.grid(column= 0, row= 0)


Generatecar=LabelFrame(window,text="Cars they are working on" ,fg="black",width=350, height=580)
Generatecar.pack_propagate(0)
Generatecar.grid(column=10,row=1)


labelpekerja1 = Label(Generatecar, text="Employe name  : ")
labelpekerja1.grid(column=0, row=1)
labelpekerja2 = Label(Generatecar, text="Car type      : ")
labelpekerja2.grid(column=0, row=2)
labelpekerja3 = Label(Generatecar, text="Date          : ")
labelpekerja3.grid(column=0, row=3)

labelpekerjaentry1=Entry(Generatecar)
labelpekerjaentry1.grid(column=1,row=1)
labelpekerjaentry2=Entry(Generatecar)
labelpekerjaentry2.grid(column=1,row=2)
labelpekerjaentry3=Entry(Generatecar)
labelpekerjaentry3.grid(column=1,row=3)


buttoncar1= Button(Generatecar,text="Add", width=12, command=add_car)
buttoncar1.grid(column=2, row=1, pady=5)

buttoncar2 = Button(Generatecar, text="Remove", width=12, command=remove_car)
buttoncar2.grid(column=2, row=2, pady=4)


buttoncar3 = Button(Generatecar, text="Clear", width=12, command=clear_car)
buttoncar3.grid(column=2, row=3, pady=5)

#parts List (listbox)
parts_list = Listbox(Generatecar,height=12,width=60)
parts_list.grid(row=9,column=0,columnspan=3,rowspan=8,padx=30,pady=20)
parts_list.bind('<<ListboxSelect>>')



employee=LabelFrame(window,text="Employe Detalis",fg="black",width=250, height=280)
employee.pack_propagate(0)
employee.grid(column=0,row=1)


label1=Label(employee,text="Employee  ID   :")
label1.grid(column=0,row=1)
label2=Label(employee,text="Shif :")
label2.grid(column=2,row=1)
label3=Label(employee,text="Car ID         :")
label3.grid(column=0,row=2)
clockin=Label(employee,text="Clock in      :")
clockin.grid(column=0,row=3)
clockout=Label(employee,text="Clock Out    :")
clockout.grid(column=0,row=4)
labelday=Label(employee,text="Day          :")
labelday.grid(column=0,row=5)


label1entry=Entry(employee)
label1entry.grid(column=1,row=1)
label2entry=Entry(employee)
label2entry.grid(column=3,row=1)
label3entry=Entry(employee)
label3entry.grid(column=1,row=2)
Clockinentry=Entry(employee)
Clockinentry.grid(column=1,row=3)
Clockoutentry=Entry(employee)
Clockoutentry.grid(column=1,row=4)
dayentry=Entry(employee)
dayentry.grid(column=1,row=5)



morningbtn=Button(employee ,text="morning", command= morning )
morningbtn.grid(column=2,row=3)
afternoonbtn=Button(employee ,text="afternoon",  command= afternoon)
afternoonbtn.grid(column=3,row=3)


button1 = Button(employee,text="Add", width=12, command=add_item)
button1.grid(column=3, row=12, pady=5)

button2 = Button(employee, text="Remove", width=12, command=remove_item)
button2.grid(column=4, row=12, pady=4)


button3 = Button(employee, text="Clear", width=12, command=clear_text)
button3.grid(column=5, row=12, pady=5)

#parts List (listbox)
parts_list1 = Listbox(employee,height=12,width=60)
parts_list1.grid(row=11,column=0,columnspan=3,rowspan=8,padx=30,pady=20)
parts_list1.bind('<<ListboxSelect>>', select_item1)



mondaybtn=Button(employee,text="Monday" ,command=monday)
mondaybtn.grid(column=0,row=8)
tuesdaybtn=Button(employee,text="Tuesday" ,command=tuesday)
tuesdaybtn.grid(column=1,row=8)
wednesdaybtn=Button(employee,text="Wednesday" ,command=wednesday)
wednesdaybtn.grid(column=2,row=8)
thursdaybtn=Button(employee,text="Thursday" ,command=thursday)
thursdaybtn.grid(column=3,row=8)
fridaybtn=Button(employee,text="Friday" ,command=friday)
fridaybtn.grid(column=0,row=9)
saturdaybtn=Button(employee,text="Saturday" ,command=saturday)
saturdaybtn.grid(column=1,row=9)
sundaybtn=Button(employee,text="Sunday" ,command=sunday)
sundaybtn.grid(column=2,row=9)



populate_list1()
window.mainloop()