from os import name
import sqlite3

class Database:
    def __init__(self,project1db):
        self.conn = sqlite3.connect(project1db)
        self.cur = self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS parts(EmployeeID integer PRIMARY KEY, CarID, ClockIn text, ClockOut text,Day text, Shif text)")
        pass

    
    def fetch(self):
        self.cur.execute("SELECT * FROM parts project1db")
        rows = self.cur.fetchall()
        return rows
    
    def insert(self,EmployeeID, CarID, Clockin, Clockout, Day, Shif):
        self.cur.execute("INSERT INTO parts VALUES (NULL,?,?,?,?,?)",(CarID, Clockin, Clockout, Day, Shif))
        self.conn.commit()

    def remove(self, EmployeeID):
        self.cur.execute("DELETE FROM parts WHERE EmployeeID= ?", 
                         (EmployeeID,))
        self.conn.commit()

    def __del__(self):
        self.conn.close()



    
      
#project1db=Database('Employee1.db')
#project1db.insert("1", "33", "8:00", "5:30", "Monday", "Morning")
##project1db.insert("3", "35", "7:30", "5:30", "Wednesday", "Afternoon")
#project1db.insert("1", "33", "8:00", "5:30", "Monday", "Morning")
#project1db.insert("2", "34", "7:00", "5:30", "Tuesday", "Afternoon")
#project1db.insert("3", "35", "7:30", "5:30", "Wednesday", "Afternoon")
#project1db.insert("4", "36", "8:30", "5:30", "Thursday", "Morning")





