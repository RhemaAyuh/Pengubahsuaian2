from os import name
import sqlite3


class Database:
     def __init__(self,workerdb):
        self.conn = sqlite3.connect(workerdb)
        self.cur = self.conn.cursor()
        self.cur.execute("CREATE TABLE IF NOT EXISTS parts(EmployeeName integer PRIMARY KEY, cartype text, date text)")
        pass

     def fetch(self):
        self.cur.execute("SELECT * FROM parts workerdb")
        rows = self.cur.fetchall()
        return rows
    
     def insert(self,EmployeeName, cartype, Date):
        self.cur.execute("INSERT INTO parts VALUES (NULL,?,?)",(cartype, Date))
        self.conn.commit()

     def remove(self, EmployeeName):
        self.cur.execute("DELETE FROM parts WHERE EmployeeName= ?", 
                         (EmployeeName,))
        self.conn.commit()
        def __del__(self):
         self.conn.close()



workerdb=Database('workerdb.db')
workerdb.insert("Ali", "Proton", "13/2")
workerdb.insert("Abu", "Toyota", "14/2")
workerdb.insert("Ahmad", "Produa", "15/2")
workerdb.insert("Azman", "Hilux", "16/2")
